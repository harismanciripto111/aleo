# snarkos-node-ledger

[![Crates.io](https://img.shields.io/crates/v/snarkos-node-ledger.svg?color=neon)](https://crates.io/crates/snarkos-node-ledger)
[![Authors](https://img.shields.io/badge/authors-Aleo-orange.svg)](https://aleo.org)
[![License](https://img.shields.io/badge/License-GPLv3-blue.svg)](./LICENSE.md)

The `snarkos-node-ledger` crate provides the ledger and API interface for the Aleo blockchain.
