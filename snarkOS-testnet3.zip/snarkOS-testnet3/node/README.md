# snarkos-node

[![Crates.io](https://img.shields.io/crates/v/snarkos-node.svg?color=neon)](https://crates.io/crates/snarkos-node)
[![Authors](https://img.shields.io/badge/authors-Aleo-orange.svg)](https://aleo.org)
[![License](https://img.shields.io/badge/License-GPLv3-blue.svg)](./LICENSE.md)

The `snarkos-node` crate provides the `Node` struct, which is responsible for running a node in the Aleo network.
