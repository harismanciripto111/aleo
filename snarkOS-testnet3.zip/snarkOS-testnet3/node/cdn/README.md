# snarkos-node-cdn

[![Crates.io](https://img.shields.io/crates/v/snarkos-node-cdn.svg?color=neon)](https://crates.io/crates/snarkos-node-cdn)
[![Authors](https://img.shields.io/badge/authors-Aleo-orange.svg)](https://aleo.org)
[![License](https://img.shields.io/badge/License-GPLv3-blue.svg)](./LICENSE.md)

The `snarkos-node-cdn` crate provides helpers for fetching ledger state from a CDN.
