# snarkos-node-tcp

[![Crates.io](https://img.shields.io/crates/v/snarkos-node-tcp.svg?color=neon)](https://crates.io/crates/snarkos-node-tcp)
[![Authors](https://img.shields.io/badge/authors-Aleo-orange.svg)](https://aleo.org)
[![License](https://img.shields.io/badge/License-GPLv3-blue.svg)](./LICENSE.md)

The `snarkos-node-tcp` crate provides the `Tcp` struct, which is responsible for establishing TCP connections between nodes.
