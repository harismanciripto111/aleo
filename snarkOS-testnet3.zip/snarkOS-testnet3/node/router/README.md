# snarkos-node-router

[![Crates.io](https://img.shields.io/crates/v/snarkos-node-router.svg?color=neon)](https://crates.io/crates/snarkos-node-router)
[![Authors](https://img.shields.io/badge/authors-Aleo-orange.svg)](https://aleo.org)
[![License](https://img.shields.io/badge/License-GPLv3-blue.svg)](./LICENSE.md)

The `snarkos-node-router` crate provides the `Router` struct, which is responsible for routing messages between nodes.
