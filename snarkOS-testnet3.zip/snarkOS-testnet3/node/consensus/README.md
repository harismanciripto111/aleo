# snarkos-node-consensus

[![Crates.io](https://img.shields.io/crates/v/snarkos-node-consensus.svg?color=neon)](https://crates.io/crates/snarkos-node-consensus)
[![Authors](https://img.shields.io/badge/authors-Aleo-orange.svg)](https://aleo.org)
[![License](https://img.shields.io/badge/License-GPLv3-blue.svg)](./LICENSE.md)

The `snarkos-node-consensus` crate provides the consensus layer for the snarkOS node.
