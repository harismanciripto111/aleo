# snarkos-node-store

[![Crates.io](https://img.shields.io/crates/v/snarkos-node-store.svg?color=neon)](https://crates.io/crates/snarkos-node-store)
[![Authors](https://img.shields.io/badge/authors-Aleo-orange.svg)](https://aleo.org)
[![License](https://img.shields.io/badge/License-GPLv3-blue.svg)](./LICENSE.md)

The `snarkos-node-store` crate provides a persistent storage layer for the `snarkos` node.
