---
name: 📚 Documentation
about: Report an issue related to documentation
title: "[Docs]"
labels: 'documentation'
---

## 📚 Documentation

<!-- Is there documentation about snarkOS that's missing or incorrect? -->
