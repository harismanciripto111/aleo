---
name: 💥 Proposal
about: Propose a non-trivial change to snarkOS
title: "[Proposal]"
labels: 'proposal'
---

## 💥 Proposal

<!-- What is your proposal for snarkOS? What are the implications of this proposal? -->
