# snarkos-cli

[![Crates.io](https://img.shields.io/crates/v/snarkos-cli.svg?color=neon)](https://crates.io/crates/snarkos-cli)
[![Authors](https://img.shields.io/badge/authors-Aleo-orange.svg)](https://aleo.org)
[![License](https://img.shields.io/badge/License-GPLv3-blue.svg)](./LICENSE.md)

The `snarkos-cli` crate provides the `CLI` struct, which is responsible for providing a command-line interface to the node.
