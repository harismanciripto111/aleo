# snarkos-display

[![Crates.io](https://img.shields.io/crates/v/snarkos-display.svg?color=neon)](https://crates.io/crates/snarkos-display)
[![Authors](https://img.shields.io/badge/authors-Aleo-orange.svg)](https://aleo.org)
[![License](https://img.shields.io/badge/License-GPLv3-blue.svg)](./LICENSE.md)

The `snarkos-display` crate provides the `Display` struct, which is responsible for displaying information about the node.
