# snarkos-account

[![Crates.io](https://img.shields.io/crates/v/snarkos-account.svg?color=neon)](https://crates.io/crates/snarkos-account)
[![Authors](https://img.shields.io/badge/authors-Aleo-orange.svg)](https://aleo.org)
[![License](https://img.shields.io/badge/License-GPLv3-blue.svg)](./LICENSE.md)

The `snarkos-account` crate provides the `Account` struct, which is responsible for managing a user's private key, view key, and address.
